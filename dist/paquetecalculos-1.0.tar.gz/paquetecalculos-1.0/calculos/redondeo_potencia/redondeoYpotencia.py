def potencia(base, exponente):
	print("El resultado de la suma es: ", base**exponente)

def redondear(numero):
	print("El resultado de la suma es: ", round(numero))