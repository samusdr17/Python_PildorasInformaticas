def sumar(op1, op2):
	print("El resultado de la suma es: ", op1+op2)

def restar(op1, op2):
	print("El resultado de la suma es: ", op1-op2)

def multiplicar(op1, op2):
	print("El resultado de la suma es: ", op1*op2)

def dividir(op1, op2):
	print("El resultado de la suma es: ", dividendo/divisor)

def potencia(op1, op2):
	print("El resultado de la suma es: ", base**exponente)

def redondear(numero):
	print("El resultado de la suma es: ", round(numero))