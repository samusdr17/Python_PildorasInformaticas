from setuptools import setup

setup(

	name="paquetecalculos",
	version="1.0",
	description="Paquete de redendeo y potencia",
	author="Juan",
	author_email="cursos@pildorasinformaticas.es",
	url="www.pildorasinformaticas.es",
	packages=["calculos","calculos.redondeo_potencia"]

	)